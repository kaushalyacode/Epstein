﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public interface ISchoolClassService
    {
        Task<bool> AddSchoolClass(SchoolClassViewModel schoolClassViewModel);
        Task<SchoolClass> GetClass(string email);

        Task<List<SchoolClass>> GetAll();

        Task<int> GetClasseId(string className);

        Task<SchoolClass> GetClassUsingId(int id);
    }
}
