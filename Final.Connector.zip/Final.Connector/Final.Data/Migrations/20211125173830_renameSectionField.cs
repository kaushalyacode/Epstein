﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Final.Data.Migrations
{
    public partial class renameSectionField : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "targetSection",
                table: "CommonNotices",
                newName: "section");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "section",
                table: "CommonNotices",
                newName: "targetSection");
        }
    }
}
