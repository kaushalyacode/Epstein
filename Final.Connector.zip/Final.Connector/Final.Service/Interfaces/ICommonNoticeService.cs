﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
     public interface ICommonNoticeService
    {
        Task<bool> AddCommonNotice(CommonNoticeViewModel commonNoticeViewModel);
        Task<List<CommonNotice>> GetSectionBasedNotices(string email);

        Task<List<CommonNotice>> GetNoticeBySection(char className);
        Task<List<CommonNotice>> GetClassBasedNotices(string className);



    }
}
