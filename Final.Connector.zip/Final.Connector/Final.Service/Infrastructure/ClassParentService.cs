﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class ClassParentService : IClassParentService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<ParentClass> _parentClassRepository { get; set; }

        private ISchoolClassService _schoolClassService;

        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }


        public ClassParentService(ISchoolClassService schoolClassService,IBaseRepository<ParentClass> repo, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _schoolClassService = schoolClassService;
            _userManager = userManager;
            this._parentClassRepository = repo;
            this._uow = uow;
            this._mapper = mapper;

        }


        public async Task<bool> AddSchoolClassAdnAssociatedTParent(ParentClassViewModel parentClassViewModel)
        {
            try
            {
                var pc = _mapper.Map<ParentClass>(parentClassViewModel);
                var user = await _userManager.FindByEmailAsync(parentClassViewModel.applicationUserEmail);
                var classId= await _schoolClassService.GetClasseId(parentClassViewModel.className);
                pc.classId = classId;
                pc.applicationUserId = user.Id;
                await _parentClassRepository.CreateAsync(pc).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        public async Task<List<ParentClass>> GetClassesForParent(string id)
        {
            if (id != null)
            {
                var classofParent = _parentClassRepository.GetByCondition(e => (e.applicationUserId == id)).ToList();
                return classofParent;
            }
            return new List<ParentClass>();
        }

        public async Task<List<ParentClass>> GetParentsForClasses(int clssid)
        {
            if (clssid != null)
            {
                var classofParent = _parentClassRepository.GetByCondition(e => (e.classId == clssid)).ToList();
                return classofParent;
            }
            return new List<ParentClass>();
        }
    }
}