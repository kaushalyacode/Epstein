﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class ParentNotificationService : IParentNotificationService
    {

        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<ParentNotification> _parentNotificationRepository { get; set; }

        private IClassParentService _classParentService;

        private ISchoolClassService _schoolClassService { get; set; }
        

        private readonly ICommonNoticeService _commonNoticeService;
        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }



        public ParentNotificationService(ISchoolClassService schoolClassService,ICommonNoticeService sv,
            IBaseRepository<ParentNotification> repo, IClassParentService classParentService,
            IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _schoolClassService = schoolClassService;
            _userManager = userManager;
            _parentNotificationRepository = repo;
            this._uow = uow;
            this._mapper = mapper;
            _commonNoticeService=sv;
            _classParentService = classParentService;
        }

        public async Task<bool> AddParentNotification(ParentsNotificationViewModel parentssNotificationViewModel)
        {
            try
            {
                ParentNotification pnf = new ParentNotification();
                pnf.NoticeId = parentssNotificationViewModel.NoticeId;
                var user = await _userManager.FindByEmailAsync(parentssNotificationViewModel.parentEmail);
                pnf.ApplicationUserId = user.Id;
                if (_parentNotificationRepository.GetAllAsync().Result
                                                .Where(e => e.NoticeId == pnf.NoticeId && pnf.ApplicationUserId == pnf.ApplicationUserId).Any()) {
                    return true;
                }
                await _parentNotificationRepository.CreateAsync(pnf).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public async Task<List<ParentNotification>> GetNotifications(string email)
        {
            if (email != null)
            {
                var user = await _userManager.FindByEmailAsync(email);
                var tn = _parentNotificationRepository.GetByCondition(e => (e.ApplicationUserId == user.Id)).ToList();
                return tn;
            }
            return new List<ParentNotification>();
        }

      
        public async Task<List<CommonNotice>> getNonReadNoticesNotifications(string email)
        {
            try
            {
                if (email != null)
                {

                    //getApplicationuser Id using email
                    var user = await _userManager.FindByEmailAsync(email);
                    //using application userid ,take class id
                    var classOfParent = _classParentService.GetClassesForParent(user.Id).Result.FirstOrDefault();
                    //using class id take className and then extract sectionname
                    var classInfo =  await _schoolClassService.GetClassUsingId(classOfParent.classId);

                    var className = classInfo.ClassName;
                    var classSection = className.FirstOrDefault();

                    //get all notices for those sec nam eand class names.specially notice id needed
                    var noticeList = await _commonNoticeService.GetClassBasedNotices(className);
                    noticeList.AddRange(
                        await _commonNoticeService.GetNoticeBySection(classSection)
                        ) ;
                    //get notice id that are occured with application user id
                    var readNoticesId =  _parentNotificationRepository.GetAllAsync().Result
                                                                    .Where(x=>x.ApplicationUserId == user.Id)
                                                                    .Select(x=>x.NoticeId);
                    foreach(var ids in readNoticesId) {

                        noticeList.RemoveAll(x => x.Id == ids);
                    }

                    return noticeList;
                }
            }
            catch (Exception e)
            {
                return new List<CommonNotice>();
            }
            return new List<CommonNotice>();
        }

        public async Task<bool> UpdateParentNotification(ParentsNotificationViewModel parentNotificationViewModel)
        {

                try{
                ParentNotification pnf = new ParentNotification();
                pnf.NoticeId = parentNotificationViewModel.NoticeId;
                var user = await _userManager.FindByEmailAsync(parentNotificationViewModel.parentEmail);

                pnf.ApplicationUserId = user.Id;
                var nf = await _parentNotificationRepository.FindByConditionAsync(e => e.NoticeId == pnf.NoticeId && e.ApplicationUserId == pnf.ApplicationUserId).ConfigureAwait(false);

               
                nf.isAccepted = true;
 

                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public async  Task<ParentsNotificationViewModel> GetNotificationState(ParentsNotificationViewModel parentNotificationViewModel)
        {
            if (parentNotificationViewModel != null)
            {
                var user = await _userManager.FindByEmailAsync(parentNotificationViewModel.parentEmail);
                var tn = _parentNotificationRepository.GetByCondition(e => (e.ApplicationUserId == user.Id && e.NoticeId == parentNotificationViewModel.NoticeId)).ToList();
                ParentsNotificationViewModel ps = new ParentsNotificationViewModel();
                if (tn.Any()) {
                    ps.NoticeId = tn.FirstOrDefault().NoticeId;
                    ps.isAccepted = tn.FirstOrDefault().isAccepted;
                }
                    return ps;
            }
            return new ParentsNotificationViewModel();
        }
    }
}
