﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class ParentViewModel
    {
        public int id { get; set; }
        public string fullname{get;set;}
        
        public string email { get; set; }
    }
}
