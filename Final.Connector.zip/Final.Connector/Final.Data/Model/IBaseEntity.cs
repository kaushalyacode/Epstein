﻿using System;

namespace Final.Data.Model
{
    public interface IBaseEntity
    {
        int Id { get; set; }
        bool IsActive { get; set; }

        bool IsDeleted { get; set; }
        DateTime AddedDateTime { get; set; }
        DateTime? UpdatedDateTime { get; set; }
        string UpdatedBy { get; set; }
        string AddedBy { get; set; }
    }
}
