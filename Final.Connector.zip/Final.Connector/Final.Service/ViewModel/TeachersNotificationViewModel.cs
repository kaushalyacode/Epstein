﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class ParentNotificationViewModel
    {
        public int Id { get; set; }
        public string ApplicationUserId { get; set; }
        public int NoticeId { get; set; }

        public string teacherEmail { get; set; }

    }
}
