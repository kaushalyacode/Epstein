using Final.Connector.HubConfig;
using Final.Data.Context;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.Security;
using Final.Data.UnitOfWork;
using Final.Service.Infrastructure;
using Final.Service.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Connector
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //Configuration from AppSettings
            services.Configure<JWTAuth>(Configuration.GetSection("JWT"));
            //User Manager Service
            services.AddIdentity<ApplicationUser, IdentityRole>().AddEntityFrameworkStores<ApplicationDbContext>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ICommonNoticeService, CommonNoticeService>();
            services.AddScoped<ISchoolClassService, SchoolClassService>();
            services.AddScoped<IClassParentService, ClassParentService>();
            services.AddScoped<ITeachersNotificationService, TeachersNotificationService>();
            services.AddScoped<IParentNotificationService, ParentNotificationService>();
            services.AddScoped<ISchoolClassTeacherService, SchoolClassTeacherService>();

            services.AddScoped<IParentTeacherMessegesService, ParentTeacherMessegesService>();
            services.AddScoped<IUnitOfWork, UnitOfWork>((provider) => new UnitOfWork(provider.GetService<ApplicationDbContext>()));


            services.AddScoped<IBaseRepository<SchoolClass>, BaseRepository<SchoolClass>>((provider) =>
          new BaseRepository<SchoolClass>(provider.GetService<ApplicationDbContext>().Set<SchoolClass>()));
            services.AddScoped<IBaseRepository<MessgeInfo>, BaseRepository<MessgeInfo>>((provider) =>
          new BaseRepository<MessgeInfo>(provider.GetService<ApplicationDbContext>().Set<MessgeInfo>()));

            services.AddScoped<IBaseRepository<ParentTeacherMesseges>, BaseRepository<ParentTeacherMesseges>>((provider) =>
                      new BaseRepository<ParentTeacherMesseges>(provider.GetService<ApplicationDbContext>().Set<ParentTeacherMesseges>()));

            services.AddScoped<IBaseRepository<ParentClass>, BaseRepository<ParentClass>>((provider) =>
          new BaseRepository<ParentClass>(provider.GetService<ApplicationDbContext>().Set<ParentClass>()));

            services.AddScoped<IBaseRepository<ParentNotification>, BaseRepository<ParentNotification>>((provider) =>
          new BaseRepository<ParentNotification>(provider.GetService<ApplicationDbContext>().Set<ParentNotification>()));

            services.AddScoped<IBaseRepository<CommonNotice>, BaseRepository<CommonNotice>>((provider) =>
         new BaseRepository<CommonNotice>(provider.GetService<ApplicationDbContext>().Set<CommonNotice>()));

            services.AddScoped<IBaseRepository<TeachersNotification>, BaseRepository<TeachersNotification>>((provider) =>
 new BaseRepository<TeachersNotification>(provider.GetService<ApplicationDbContext>().Set<TeachersNotification>()));

            services.AddScoped<IBaseRepository<SchoolClassTeacher>, BaseRepository<SchoolClassTeacher>>((provider) =>
         new BaseRepository<SchoolClassTeacher>(provider.GetService<ApplicationDbContext>().Set<SchoolClassTeacher>()));

            //Adding DB Context with MSSQL
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(
                    Configuration.GetConnectionString("DefaultConnection"),
                    b => b.MigrationsAssembly(typeof(ApplicationDbContext).Assembly.FullName)));
            //Adding Athentication - JWT
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddJwtBearer(o =>
                {
                    o.RequireHttpsMetadata = false;
                    o.SaveToken = false;
                    o.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ClockSkew = TimeSpan.Zero,
                        ValidIssuer = Configuration["JWT:Issuer"],
                        ValidAudience = Configuration["JWT:Audience"],
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JWT:Key"]))
                    };
                });
            services.AddAutoMapper(typeof(Startup));
            services.AddControllers();

            services.AddSignalR();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Final.Connector", Version = "v1" });
            });
            services.AddCors(options =>
            {
                options.AddPolicy("EnableCORS", builder => builder
        .WithOrigins("http://localhost:4200")
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials());
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Final.Connector v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors("EnableCORS");

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<NoticeHub>("/notify");
            });
        }
    }
}
