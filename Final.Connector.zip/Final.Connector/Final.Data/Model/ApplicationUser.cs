﻿namespace Final.Data.Model
{
    using Microsoft.AspNetCore.Identity;
    public class ApplicationUser : IdentityUser
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public SchoolClass SchoolClass { get; set; }
    }
}
