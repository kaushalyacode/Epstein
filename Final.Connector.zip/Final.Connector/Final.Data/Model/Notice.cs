﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Data.Model
{ 
    public class Notice : BaseEntity
    {
        public string description { get; set; }
        public DateTime time { get; set; }
        public string name { get; set; }
        public Boolean isParenting { get; set; }
        public Boolean isClassMeeting { get; set; }
        public Boolean isVolunteering { get; set; }
        public int accept { get; set; }
        public int decline { get; set; }
        public Boolean isMandotory { get; set; }
        public string targetSection { get; set; }
        public string targetClass { get; set; }

 
    }
}
