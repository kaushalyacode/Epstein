﻿namespace Final.Service.ViewModel
{


    public class ParentClassViewModel
    {
        public int classId { get; set; }
        public string className { get; set; }
        public string applicationUserId { get; set; }
        public string applicationUserEmail { get; set; }
    }
}
