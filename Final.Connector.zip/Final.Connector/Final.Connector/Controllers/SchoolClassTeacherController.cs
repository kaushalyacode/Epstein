﻿using Final.Data.Model;
using Final.Service.Infrastructure;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolClassTeacherController : ControllerBase
    {
        private readonly ISchoolClassTeacherService schoolClassTeacherService;
        private readonly ISchoolClassService schoolClassSevice;
        private readonly UserManager<ApplicationUser> userManager;
        private readonly IClassParentService classParentService;
        public SchoolClassTeacherController(IClassParentService _classParentService,UserManager<ApplicationUser> _userManager,ISchoolClassTeacherService _schoolClassTeacherService, ISchoolClassService _schoolClassSevice)
        {
            schoolClassSevice = _schoolClassSevice;
            schoolClassTeacherService = _schoolClassTeacherService;
            userManager = _userManager;
            classParentService = _classParentService;
        }

        [HttpGet("getClassesForTeachers/{email}")]
        public async Task<ActionResult> GetActionTeachersForClass(string email) 
        {

            //take classes he/she teaches
            //then those class informations 
            if (email != null)
            {
                List<HomeRoomTeacherViewModel> hrtv = new List<HomeRoomTeacherViewModel>();
                var allClassInfor = await schoolClassTeacherService.GetClassesForTeacher(email);
                foreach (var classInfo in allClassInfor)
                {
                    var schoolClass = await schoolClassSevice.GetClassUsingId(classInfo.classId);
                    HomeRoomTeacherViewModel hr = new HomeRoomTeacherViewModel();
                    hr.id = classInfo.classId;
                    hr.className = schoolClass.ClassName;
                    hr.name =  userManager.FindByIdAsync(schoolClass.ApplicationUserID).Result.FirstName + " "+
                               userManager.FindByIdAsync(schoolClass.ApplicationUserID).Result.LastName;

                    hrtv.Add(hr);

                }
                return Ok(hrtv);
            }
            return BadRequest();
        
        }

        [HttpPost("addTeachersForClass")]
        public async Task<ActionResult> AddActionTeachersForClass(SchoolClassTeacherViewModel schoolClassTeacherViewModel)
        {


            //get class id for class Name
            int classId = await schoolClassSevice.GetClasseId(schoolClassTeacherViewModel.className);
            schoolClassTeacherViewModel.classId = classId;

            if (await schoolClassTeacherService.AddSchoolClassAdnAssociatedTeacher(schoolClassTeacherViewModel))
            {
                return Ok("success");
            }
            else
            {
                return Ok("Failed");
            }

        }


        [HttpGet("GetClassTeacherInfor/{email}")]
        public async Task<ActionResult> GetClassTeacherInfor(string email)
        {
            //getClassinfor base on class id 
            var parent = await userManager.FindByEmailAsync(email);
            var classes =await classParentService.GetClassesForParent(parent.Id);
            var listofTeachInfor =  await schoolClassTeacherService.GetTeachersForClasses(classes.FirstOrDefault().classId);
            
            var listOfShowableTeachers = new List<TeachersForClassViewModel>();
            int x = 0;
            foreach (var teacher in listofTeachInfor) 
            {

                var showableTeacher = new TeachersForClassViewModel();
                x++;
                showableTeacher.Id = x;
                showableTeacher.subject = teacher.subject;
                var user = await userManager.FindByIdAsync(teacher.classTeacherId);
                showableTeacher.name = user.FirstName + " " + user.LastName;
                showableTeacher.email = userManager.FindByIdAsync(teacher.classTeacherId).Result.Email;

                listOfShowableTeachers.Add(showableTeacher);
            }
            return Ok(listOfShowableTeachers);
        }

    }
}
