﻿namespace Final.Connector.Controllers
{
    using AutoMapper;
    using Final.Connector.HubConfig;
    using Final.Data.Model;
    using Final.Service.Interfaces;
    using Final.Service.ViewModel;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.AspNetCore.SignalR;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    [Route("api/[controller]")]
    [ApiController]
    public class NoticeController : ControllerBase
    {
        private readonly ICommonNoticeService _commonNoticeService;
        private readonly IClassParentService _classParentService;
        private readonly ISchoolClassService _schoolClassService;
        private readonly IHubContext<NoticeHub> _hub;
        private UserManager<ApplicationUser> _userManager;

        public NoticeController(ISchoolClassService schoolClassService, UserManager<ApplicationUser> userManager,
            IClassParentService classParentService,ICommonNoticeService commonNoticeService, IHubContext<NoticeHub> hub)
        {
            _commonNoticeService = commonNoticeService;
            _schoolClassService = schoolClassService;
            _hub = hub;
            _userManager = userManager;
            _classParentService = classParentService;
        }
        [HttpPost("addCommonNotice")]
        [Authorize(Roles = "Teacher")]
        public async Task<ActionResult> AddCommonNotice(CommonNoticeViewModel commonNoticeViewModel)
        {
            if (await _commonNoticeService.AddCommonNotice(commonNoticeViewModel))
            {
                _hub.Clients.All.SendAsync("test","test");
                return Ok(200);
            }
            else
            {
                return Ok(500);
            }
        }

        
        [HttpGet("getAllSectionalNotices/{email}")]
        public async Task<ActionResult> GetSectionNotice(string email)
        {
            var Notices = await _commonNoticeService.GetSectionBasedNotices(email);
            if (Notices != null && Notices.Any())
            {
                    return Ok(Notices.OrderByDescending(x => x.AddedDateTime));
            }
            return Ok(new List<Notice>());
        }

        [HttpGet("getClassbasedlNotices/{classid}")]
        public async Task<ActionResult> GetClassbasedlNotices(int classid)
        {
            //take the class name  uing class  id
            //take all notices that has targetClass name is this
            var schoolClass = await _schoolClassService.GetClassUsingId(classid);
            if (schoolClass != null)
            {
                var Notices = await _commonNoticeService.GetClassBasedNotices(schoolClass.ClassName);
                if (Notices != null && Notices.Any())
                {
                    return Ok(Notices.OrderByDescending(x => x.AddedDateTime));
                }
            }
            return Ok(new List<Notice>());
        }


        [HttpGet("getClassName/{classid}")]
        public async Task<ActionResult> GetClassName(int classid)
        {
            var schoolClass = await _schoolClassService.GetClassUsingId(classid);
            return Ok(schoolClass);
        }

        [HttpGet("getAllNoticesForParents/{email}")]
        public async Task<ActionResult> GetAllNoticesForParents(string email)
        {
            //GET  PARENT ID
            var user = await _userManager.FindByEmailAsync(email);
            //GET CLASS ID OF PARENT ID
            var classOfParent  =_classParentService.GetClassesForParent(user.Id).Result.FirstOrDefault();
            //GET NOTICES FOR SECTION HE IN AND CLASS HE IN
            var className = _schoolClassService.GetClassUsingId(classOfParent.classId).Result.ClassName;
            var secdtionName = className.FirstOrDefault();

            var Notices = await _commonNoticeService.GetClassBasedNotices(className);
            Notices.AddRange(
                await _commonNoticeService.GetNoticeBySection(secdtionName)
                ) ;
            if (Notices != null && Notices.Any())
            {
                return Ok(Notices.OrderByDescending(x => x.AddedDateTime));
            }
            return Ok(new List<Notice>());
        }

        [HttpGet("getAllNoticesForParentsRemainder/{email}")]
        public async Task<ActionResult> getAllNoticesForParentsRemainder(string email)
        {
            //GET  PARENT ID
            var user = await _userManager.FindByEmailAsync(email);
            //GET CLASS ID OF PARENT ID
            var classOfParent = _classParentService.GetClassesForParent(user.Id).Result.FirstOrDefault();
            //GET NOTICES FOR SECTION HE IN AND CLASS HE IN
            var className = _schoolClassService.GetClassUsingId(classOfParent.classId).Result.ClassName;
            var secdtionName = className.FirstOrDefault();

            var Notices = await _commonNoticeService.GetClassBasedNotices(className);
            if (Notices.Any()) { 
            Notices.FirstOrDefault().time = DateTime.Now.AddDays(2);
            Notices.LastOrDefault().time = DateTime.Now.AddDays(2);

            Notices.AddRange(
                await _commonNoticeService.GetNoticeBySection(secdtionName)
                );
            var targetedDate = DateTime.Now.AddDays(2);
            Notices = Notices.Where(e => e.time <= targetedDate && DateTime.Now <= e.time).ToList();
            if (Notices != null && Notices.Any())
            {
                return Ok(Notices.OrderByDescending(x => x.AddedDateTime));
            }
        }
            return Ok(new List<Notice>());
        }
    }
}
