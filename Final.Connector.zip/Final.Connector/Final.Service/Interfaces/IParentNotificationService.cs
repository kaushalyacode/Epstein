﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public  interface IParentNotificationService
    {
        Task<bool> AddParentNotification(ParentsNotificationViewModel parentNotificationViewModel);
        Task<bool> UpdateParentNotification(ParentsNotificationViewModel parentNotificationViewModel);
        Task<List<ParentNotification>> GetNotifications(string email);
        Task<ParentsNotificationViewModel> GetNotificationState(ParentsNotificationViewModel parentNotificationViewModel);
        Task<List<CommonNotice>> getNonReadNoticesNotifications(string email);
    }
}
