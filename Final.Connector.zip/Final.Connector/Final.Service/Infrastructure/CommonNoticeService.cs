﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class CommonNoticeService : ICommonNoticeService
    {

        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<CommonNotice> _commonNoticeRepository { get; set; }

        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }




        public CommonNoticeService(IBaseRepository<CommonNotice> repo, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            this._commonNoticeRepository = repo;
            this._uow = uow;
            this._mapper = mapper;

        }
        public async Task<bool> AddCommonNotice(CommonNoticeViewModel commonNoticeViewModel)
        {
            try
            {
                CommonNotice commonNotice = _mapper.Map<CommonNotice>(commonNoticeViewModel);
                commonNotice.time = commonNotice.AddedDateTime;
                var user = await _userManager.FindByEmailAsync(commonNoticeViewModel.email);
                commonNotice.teacherId = user.Id;
                commonNotice = await _commonNoticeRepository.CreateAsync(commonNotice).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public async Task<List<CommonNotice>> GetSectionBasedNotices(string email)
        {
            try
            {
                if (email != null)
                {
                    var user = await _userManager.FindByEmailAsync(email);
                    var commonNotices = _commonNoticeRepository.GetByCondition(e => (e.teacherId == user.Id)).ToList();
                    return commonNotices;
                }
            }
            catch (Exception e) { }
            return new List<CommonNotice>();
        }

        public async Task<List<CommonNotice>> GetClassBasedNotices(string className)
        {
            if (className != null)
            {
                var commonNotices = _commonNoticeRepository.GetByCondition(e => (e.targetClass == className)).ToList();
                return commonNotices;
            }
            return new List<CommonNotice>();
        }

        public async Task<List<CommonNotice>> GetNoticeBySection(char className)
        {
            if (className != null)
            {
                var commonNotices = _commonNoticeRepository.GetByCondition(e => (e.section == className.ToString())).ToList();
                return commonNotices;
            }
            return new List<CommonNotice>();
        }


    }
}

