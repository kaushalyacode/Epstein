﻿using Final.Data.Model;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParentNotificationController : ControllerBase
    {

        private readonly IParentNotificationService _parentNotificationService;
       
        public ParentNotificationController(IParentNotificationService parentNotificationService)
        {
            _parentNotificationService = parentNotificationService;

    }

        [HttpGet("getNonReadNoticesforClassParent/{email}")]
        public async Task<List<CommonNotice>> getNonReadNoticesforClassParent(string email)
        {

            var notices = await _parentNotificationService.getNonReadNoticesNotifications(email);
            if (notices.Any()) {
                return notices;
            }
            return new List<CommonNotice>();

        }

        [HttpPut("addToReadUpdate")]
        public async Task<ActionResult> AddToReadUpdate(ParentsNotificationViewModel ptf)
        {
            if (await _parentNotificationService.UpdateParentNotification(ptf))
            {
             //   _hub.Clients.All.SendAsync("test", "test");
                return Ok(200);
            }
            else
            {
                return Ok(500);
            }
        }

        [HttpPost("addToRead")]
        public async Task<bool> addToRead(ParentsNotificationViewModel tnvm)
        {

            var success = await _parentNotificationService.AddParentNotification(tnvm);
            if (success)
            {
                return true;
            }
            return false;
        }

        [HttpPost("getNotificationState")]
        public async Task<IActionResult> GetNotificationState(ParentsNotificationViewModel prn)
        {

            var success = await _parentNotificationService.GetNotificationState(prn);
            return Ok(success);
        }

    }
}
