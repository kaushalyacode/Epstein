﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class TeachersForClassViewModel
    {
        public int Id { get; set; }
        public string subject { get; set; }
        public string name { get; set; }
        public string email { get; set; }

    }
}
