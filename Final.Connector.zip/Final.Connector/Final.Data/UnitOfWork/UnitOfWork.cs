﻿using Final.Data.Context;
using System;
using System.Threading.Tasks;

namespace Final.Data.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {


        private ApplicationDbContext applicationDbContext { get; set; }

        public UnitOfWork(ApplicationDbContext _applicationDbContext)
        {
            this.applicationDbContext = _applicationDbContext;
        }

        public async Task Commit()
        {
            try
            {
                await applicationDbContext.SaveChangesAsync().ConfigureAwait(true);
            }
            catch (Exception ex)
            {
               
            }
        }


    }
}
