﻿using Final.Data.Model;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherNotificationController : ControllerBase
    {

        private readonly ITeachersNotificationService _teacherNotificationService;
       
        public TeacherNotificationController(ITeachersNotificationService teacherNotificationService)
        {
            _teacherNotificationService = teacherNotificationService;

    }

        [HttpGet("getNonReadNoticesforClass/{email}")]
        public async Task<List<CommonNotice>> getNonReadNoticesforClass(string email)
        {

            var notices = await _teacherNotificationService.getNonReadNoticesNotifications(email);
            if (notices.Any()) {
                return notices;
            }
            return new List<CommonNotice>();

        }

        [HttpPost("addToRead")]
        public async Task<bool> addToRead(ParentNotificationViewModel tnvm)
        {

            var success = await _teacherNotificationService.AddTeacherNotification(tnvm);
            if (success)
            {
                return true;
            }
            return false;
        }
    }
}
