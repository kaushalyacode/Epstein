﻿namespace Final.Service.ViewModel
{


    public class SchoolClassTeacherViewModel
    {
        public string classTeacherId { get; set; }
        public int classId { get; set; }
        public string subject { get; set; }
        public string classTeacherEmail { get; set; }

        public string className { get; set; }
    }
}
