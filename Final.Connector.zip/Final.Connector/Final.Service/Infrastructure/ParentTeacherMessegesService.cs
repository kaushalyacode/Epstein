﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class ParentTeacherMessegesService : IParentTeacherMessegesService

    {


        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<ParentTeacherMesseges> _parentTeacherMessegesNoticeRepository { get; set; }


        private IBaseRepository<MessgeInfo> _messgeInfoRepository { get; set; }

        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }




        public ParentTeacherMessegesService(IBaseRepository<ParentTeacherMesseges> repo, IBaseRepository<MessgeInfo> repo1, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            this._parentTeacherMessegesNoticeRepository = repo;
            this._messgeInfoRepository = repo1;
            this._uow = uow;
            this._mapper = mapper;

        }

        public async Task<bool> AddMessge(ParentTeacherMessegesViewModel pm)
        {

            try
            {
                ParentTeacherMesseges ptm = new ParentTeacherMesseges();
                MessgeInfo mif = new MessgeInfo();

                ptm.ParentId = _userManager.FindByEmailAsync(pm.email).Result.Id;
                ptm.TeacherId = _userManager.FindByEmailAsync(pm.temail).Result.Id;
                var record = _parentTeacherMessegesNoticeRepository.FindByConditionAsync(e => e.ParentId == ptm.ParentId &&
               e.TeacherId == ptm.TeacherId).Result;
                if (record == null)
                {
                    var result = await _parentTeacherMessegesNoticeRepository.CreateAsync(ptm).ConfigureAwait(false);
                    //mif.Mseeage = pm.messge;
                    mif.SenderRole = "Parent";

                    await _uow.Commit().ConfigureAwait(false);
                    var id = await _parentTeacherMessegesNoticeRepository.FindByConditionAsync(e => e.TeacherId == ptm.TeacherId && e.ParentId == ptm.ParentId).ConfigureAwait(false);
                    mif.Mseeage = pm.messge;
                    mif.ConnectionId = id.Id;
                    await this._messgeInfoRepository.CreateAsync(mif).ConfigureAwait(false);

                }
                else
                {
                    mif.Mseeage = pm.messge;
                    mif.SenderRole = "Parent";
                    mif.ConnectionId = record.Id;
                    await this._messgeInfoRepository.CreateAsync(mif).ConfigureAwait(false);

                }
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;

        }

        public async Task<bool> AddMessgeByTeacher(ParentTeacherMessegesViewModel pm)
        {

            try
            {
                ParentTeacherMesseges ptm = new ParentTeacherMesseges();
                MessgeInfo mif = new MessgeInfo();

                ptm.ParentId = _userManager.FindByEmailAsync(pm.email).Result.Id;
                ptm.TeacherId = _userManager.FindByEmailAsync(pm.temail).Result.Id;

                var record = _parentTeacherMessegesNoticeRepository.FindByConditionAsync(e => e.ParentId == ptm.ParentId &&
               e.TeacherId == ptm.TeacherId).Result;
                if (record == null)
                {
                    var result = await _parentTeacherMessegesNoticeRepository.CreateAsync(ptm).ConfigureAwait(false);

                    mif.Mseeage = pm.messge;
                    mif.SenderRole = "Teacher";
                    mif.ConnectionId = result.Id;
                    await _uow.Commit().ConfigureAwait(false);
                    var id = await _parentTeacherMessegesNoticeRepository.FindByConditionAsync(e => e.TeacherId == ptm.TeacherId && e.ParentId == ptm.ParentId).ConfigureAwait(false);

                    mif.ConnectionId = id.Id;

                    await this._messgeInfoRepository.CreateAsync(mif).ConfigureAwait(false);

                }
                else
                {
                    mif.Mseeage = pm.messge;
                    mif.SenderRole = "Teacher";
                    mif.ConnectionId = record.Id;
                    await this._messgeInfoRepository.CreateAsync(mif).ConfigureAwait(false);

                }
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;

        }

        public async  Task<int> getConnectionId(string teacherid, string parentid)
        {
                var id = _parentTeacherMessegesNoticeRepository.GetByCondition(e => (e.ParentId == parentid && e.TeacherId ==teacherid)).ToList();
                if(id.Any())
                return id.FirstOrDefault().Id;

            return 0;
        }

        public async Task<List<MessgeInfo>> getMessgesForTeacher(int connectionid)
        {
          var messges  =   _messgeInfoRepository.GetByCondition(E => E.ConnectionId == connectionid).ToList();
          return messges;
        }
    }
}
