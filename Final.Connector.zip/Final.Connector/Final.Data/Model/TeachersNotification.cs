﻿namespace Final.Data.Model
{
    public class TeachersNotification:BaseEntity
    {
        public string ApplicationUserId { get; set; }

        public int NoticeId { get; set; }

    }
}
