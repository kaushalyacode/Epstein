﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Final.Data.Migrations
{
    public partial class addNewFieldsToNotice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "accept",
                table: "Notices",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "decline",
                table: "Notices",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "isClassMeeting",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "isMandotory",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "isParenting",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "isVolunteering",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "name",
                table: "Notices",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "targetClass",
                table: "Notices",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "targetSection",
                table: "Notices",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "time",
                table: "Notices",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "accept",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "decline",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "isClassMeeting",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "isMandotory",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "isParenting",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "isVolunteering",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "name",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "targetClass",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "targetSection",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "time",
                table: "Notices");
        }
    }
}
