﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Data.Model
{
    public class SchoolClassTeacher : BaseEntity
    {
        public string classTeacherId { get; set; }
        public int classId { get; set; }

        public string subject { get; set; }
    }
}
