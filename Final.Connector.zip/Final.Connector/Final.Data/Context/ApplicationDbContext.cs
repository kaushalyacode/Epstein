﻿namespace Final.Data.Context
{
   
    using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore;
    using Model;
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        DbSet<Notice> Notices { get; set; }
        DbSet<CommonNotice> CommonNotices { get; set; }
        DbSet<TeachersNotification> TeachersNotification { get; set; }
        DbSet<SchoolClass> SchoolClass { get; set; }
        DbSet<SchoolClassTeacher> SchoolClassTeacher { get; set; }
        DbSet<ParentNotification> ParentNotification { get; set; }
        DbSet<ParentClass> ParentClass{ get; set; }

        DbSet<MessgeInfo> MessgeInfo { get; set; }

        DbSet<ParentTeacherMesseges> ParentTeacherMesseges { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }
    }
}
