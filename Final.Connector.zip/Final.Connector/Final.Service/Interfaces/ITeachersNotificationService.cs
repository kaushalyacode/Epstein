﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public  interface ITeachersNotificationService
    {
        Task<bool> AddTeacherNotification(ParentNotificationViewModel teachersNotificationViewModel);
        Task<List<TeachersNotification>> GetNotifications(string email);
        Task<List<CommonNotice>> getNonReadNoticesNotifications(string email);
    }
}
