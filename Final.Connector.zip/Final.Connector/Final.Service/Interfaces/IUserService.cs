﻿using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public interface IUserService
    {
        Task<string> RegisterAsync(UserViewModel user);
        Task<AuthenticationViewModel> GetTokenAsync(TokenRequestViewModel model);
        Task<string> AddRoleAsync(AddRoleViewModel model);
    }
}
