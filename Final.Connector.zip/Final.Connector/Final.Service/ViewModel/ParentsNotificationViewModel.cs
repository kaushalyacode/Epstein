﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class ParentsNotificationViewModel
    {
        public int Id { get; set; }
        public string ApplicationUserId { get; set; }
        public int NoticeId { get; set; }

        public string parentEmail { get; set; }

        public bool isAccepted {get;set;}
    }
}
