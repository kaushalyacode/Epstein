﻿using System.Threading.Tasks;

namespace Final.Data.UnitOfWork
{
    public interface IUnitOfWork
    {
        Task Commit();
    }
}
