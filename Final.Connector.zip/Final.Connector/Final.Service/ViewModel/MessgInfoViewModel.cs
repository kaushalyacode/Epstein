﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class MessgInfoViewModel
    {
        public string Mseeage { get; set; }
        public int  ConnectionId { get; set; }
        public string SenderRole { get; set; }
    }
}
