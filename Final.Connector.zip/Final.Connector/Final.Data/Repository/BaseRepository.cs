﻿using Final.Data.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Final.Data.Repository
{
    public class BaseRepository<T> : IBaseRepository<T>
        where T : class, IBaseEntity
    {


        protected DbSet<T> ApplicationDbContext { get; set; }

        public BaseRepository(DbSet<T> applicationDbContext)
        {
            this.ApplicationDbContext = applicationDbContext;
        }

        public async Task<List<T>> GetAllAsync()
        {

            return await ApplicationDbContext.ToListAsync().ConfigureAwait(true);


        }
        public IQueryable<T> GetAll()
        {
            return ApplicationDbContext;
        }

        public async Task<T> FindAsync(object keys)
        {
            var entity = await ApplicationDbContext.FindAsync(keys);
            return (entity != null) ? entity : null;
        }

        public async Task<T> FindByConditionAsync(Expression<Func<T, bool>> expression)
        {
            return await GetAll().Where(expression).FirstOrDefaultAsync().ConfigureAwait(true);
        }

        public IQueryable<T> GetByCondition(Expression<Func<T, bool>> expression)
        {
            return GetAll().Where(expression);
        }

        public async Task<T> CreateAsync(T entity)
        {
            return (await this.ApplicationDbContext.AddAsync(entity)).Entity;
        }

        public async Task CreateRangeAsync(IEnumerable<T> entities)
        {
            await ApplicationDbContext.AddRangeAsync(entities).ConfigureAwait(true);
        }

        public async Task<T> UpdateAsync(T entity)
        {

            return (await Task.Run(() => ApplicationDbContext.Update(entity)).ConfigureAwait(true)).Entity;
        }

        public async Task UpdateListAsync(IEnumerable<T> entities)
        {
            await Task.Run(() => ApplicationDbContext.UpdateRange(entities)).ConfigureAwait(true);
        }

        public async Task DeleteAsync(T entity)
        {
            if (entity != null)
            {
                await Task.Run(() => ApplicationDbContext.Remove(entity)).ConfigureAwait(true);
            }
        }

        public async Task DeleteListAsync(IEnumerable<T> entities)
        {
            if (entities != null)
            {
                foreach (T entity in entities)
                {
                    entity.IsDeleted = true;
                }
                await UpdateListAsync(entities).ConfigureAwait(true);
            }
        }
        public async Task DeleteRange(IEnumerable<T> entities)
        {

            ApplicationDbContext.RemoveRange(entities);

        }
    }
}
