﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class SchoolClassViewModel
    {
        public int id { get; set; }
        public string ClassName { get; set; }     
        public string ApplicationUserID { get; set; }

        public string homeRoomTeacherEmail { get; set; }
    }
}
