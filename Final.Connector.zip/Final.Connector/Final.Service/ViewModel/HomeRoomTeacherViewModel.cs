﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.ViewModel
{
    public class HomeRoomTeacherViewModel
    {
        public int id { get; set; }
        public string className { get; set; }
        public string name { get; set; }

    }
}
