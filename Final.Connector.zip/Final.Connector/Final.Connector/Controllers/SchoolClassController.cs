﻿using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SchoolClassController : ControllerBase
    {
        private readonly ISchoolClassService schoolClassService; 
        public SchoolClassController(ISchoolClassService _schoolClassService)
        {
            schoolClassService = _schoolClassService;
        }

        [HttpPost("addnewClass")]
        public async Task<ActionResult> AddNewClass(SchoolClassViewModel schoolClassViewModel) 
        {
            if (schoolClassViewModel != null)
            {
               
                await schoolClassService.AddSchoolClass(schoolClassViewModel);
                return Ok();
            }
            return BadRequest();
        }
    }
}
