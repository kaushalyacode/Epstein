﻿using Final.Connector.HubConfig;
using Final.Data.Model;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
        private readonly IParentTeacherMessegesService parentTeacherMessegesService;
        private UserManager<ApplicationUser> _userManager;
        private readonly IHubContext<NoticeHub> _hub;

        public MessageController(IHubContext<NoticeHub> hub,IParentTeacherMessegesService _parentTeacherMessegesService, UserManager<ApplicationUser> userManager)
        {
            _hub = hub;
            _userManager = userManager;
            this.parentTeacherMessegesService = _parentTeacherMessegesService;
        }
        [HttpPost("sendByParent")]
        public async Task<ActionResult> SendByParent(ParentTeacherMessegesViewModel pm)
        {
            try
            {
                var result = await this.parentTeacherMessegesService.AddMessge(pm);
                return Ok(result);

            }
            catch (Exception e)
            {

                throw e;
            }
            return Ok();
        }

        [HttpPost("sendByTeacher")]
        public async Task<ActionResult> sendByTeacher(ParentTeacherMessegesViewModel pm)
        {
            try
            {
                var result = await this.parentTeacherMessegesService.AddMessgeByTeacher(pm);
                return Ok(result);

            }
            catch (Exception e)
            {

                throw e;
            }
            return Ok();
        }

        [HttpGet("getAllMessgesForTeacher/{email}/{emailofparent}")]
        public async Task<List<MessgInfoViewModel>> getAllMessgesForTeacher(string email, string emailofparent)
        {
            var parent = await _userManager.FindByEmailAsync(emailofparent);

            var teacher = await _userManager.FindByEmailAsync(email);

            var cid =await parentTeacherMessegesService.getConnectionId(teacher.Id, parent.Id);
            var messges = await parentTeacherMessegesService.getMessgesForTeacher(cid);
            List<MessgInfoViewModel> vm = new List<MessgInfoViewModel>();
            foreach (var m in messges)
            {
                MessgInfoViewModel ms = new MessgInfoViewModel();
                ms.ConnectionId = m.ConnectionId;
                ms.SenderRole = m.SenderRole;
                ms.Mseeage = m.Mseeage;
                vm.Add(ms);
            }
            _hub.Clients.All.SendAsync("transferdata", vm);
            return vm;
        }
    }
}
 
