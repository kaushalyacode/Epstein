﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    //Teachers have home room classes => one teacher has one home room class
    public class SchoolClassService : ISchoolClassService
    {

        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<SchoolClass> _schoolClassRepository { get; set; }

        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }



        public SchoolClassService(IBaseRepository<SchoolClass> repo, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            this._schoolClassRepository = repo;
            this._uow = uow;
            this._mapper = mapper;

        }
        public async Task<bool> AddSchoolClass(SchoolClassViewModel schoolClassViewModel)
        {
            try
            {
                SchoolClass schoolClass = _mapper.Map<SchoolClass>(schoolClassViewModel);
                schoolClass.numberOfStudents = 50;
                var user = await _userManager.FindByEmailAsync(schoolClassViewModel.homeRoomTeacherEmail);
                schoolClass.ApplicationUserID = user.Id;
                await _schoolClassRepository.CreateAsync(schoolClass).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        //Home Room of teacher
        public async Task<SchoolClass> GetClass(string email)
        {
            if (email != null)
            {
                var user = await _userManager.FindByEmailAsync(email);
                var schoolClass = _schoolClassRepository.GetByCondition(e => (e.ApplicationUserID == user.Id)).ToList();
                return schoolClass.FirstOrDefault();
            }
            return new SchoolClass();
        }

        public async Task<int> GetClasseId(string className)
        {
            if (className != null)
            {
                
                var schoolClass = _schoolClassRepository.GetByCondition(e => (e.ClassName == className)).ToList().FirstOrDefault();
                return schoolClass.Id;
            }
            return 0;
        }

        public async Task<List<SchoolClass>> GetAll()
        {
          
                return await _schoolClassRepository.GetAllAsync().ConfigureAwait(true);
           
        }

        public async Task<SchoolClass> GetClassUsingId(int id)
        {
            if (id != null)
            {

                var schoolClass = _schoolClassRepository.GetByCondition(e => (e.Id == id)).ToList().FirstOrDefault();
                return schoolClass;
            }
            return new SchoolClass();
        }
    }
}
