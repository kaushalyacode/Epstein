﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Data.Model
{
    public class ParentTeacherMesseges :BaseEntity
    {
        public string TeacherId { get; set; }
        public string ParentId { get; set; }
    }
}
