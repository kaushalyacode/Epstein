﻿using Final.Data.Model;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Final.Data.Repository
{
    public interface IBaseRepository<T>
        where T : class, IBaseEntity
    {
        IQueryable<T> GetAll();

        Task<List<T>> GetAllAsync();
        Task<T> FindAsync(object keys);
        Task<T> FindByConditionAsync(Expression<Func<T, bool>> expression);
        IQueryable<T> GetByCondition(Expression<Func<T, bool>> expression);
        Task<T> CreateAsync(T entity);
        Task CreateRangeAsync(IEnumerable<T> entities); 
        Task<T> UpdateAsync(T entity);
        Task UpdateListAsync(IEnumerable<T> entities);
        Task DeleteAsync(T entity);
        Task DeleteListAsync(IEnumerable<T> entities);
        Task DeleteRange(IEnumerable<T> entities);
    }
}
