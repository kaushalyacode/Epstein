﻿using AutoMapper;
using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Mapper
{
    public class ApplicationMapper :Profile
    {
        public ApplicationMapper()
        {
            CreateMap<CommonNoticeViewModel, CommonNotice>()
              .ReverseMap();
            CreateMap<SchoolClassViewModel, SchoolClass>()
              .ReverseMap();
            CreateMap<SchoolClassViewModel, SchoolClassTeacher>()
              .ReverseMap();
            CreateMap<TeachersNotification, ParentNotificationViewModel>()
              .ReverseMap();

            CreateMap<ParentNotification, ParentNotificationViewModel>()
              .ReverseMap();
            CreateMap<ParentClass, ParentClassViewModel>()
          .ReverseMap();
        }
    }
}

