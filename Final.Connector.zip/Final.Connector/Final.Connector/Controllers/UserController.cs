﻿using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }
  /*      {
  "firstName": "teacher",
  "lastName": "three",
  "username": "t_2",
  "email": "teacherthree@gmail.com",
  "password": "T#3t"
}*/

    [HttpPost("register")]
        public async Task<ActionResult> RegisterAsync(Service.UserViewModel model)
        {
            var result = await _userService.RegisterAsync(model);
            return Ok(result);
        }

        [HttpPost("token")]
        public async Task<IActionResult> GetTokenAsync(TokenRequestViewModel model)
        {
            var result = await _userService.GetTokenAsync(model);
            return Ok(result);
        }
        [HttpPost("addrole")]
        public async Task<IActionResult> AddRoleAsync(AddRoleViewModel model)
        {
            var result = await _userService.AddRoleAsync(model);
            return Ok(result);
        }
        [HttpGet("test")]
        public async Task<IActionResult> test()
        {

            return Ok(new CommonNoticeViewModel
            {
                accept = 12,
                decline = 90,
                description="fksr"
            }) ;
        }
    }

}
