﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public interface IClassParentService
    {
        Task<bool> AddSchoolClassAdnAssociatedTParent(ParentClassViewModel parentClassViewModel);
        Task<List<ParentClass>> GetClassesForParent(string id);

        Task<List<ParentClass>> GetParentsForClasses(int clssid);
    }
}
