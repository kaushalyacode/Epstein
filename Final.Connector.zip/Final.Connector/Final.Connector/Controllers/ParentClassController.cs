﻿using Final.Data.Model;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParentClassController : ControllerBase
    {


        private UserManager<ApplicationUser> _userManager;
        private readonly IClassParentService _classParentService;
        public ParentClassController(IClassParentService classParentService, UserManager<ApplicationUser> userManager)
        {

            _userManager = userManager;
            _classParentService = classParentService;
        }
        [HttpPost("addParentToClass")]
        public async Task<ActionResult> addParentToClass(ParentClassViewModel pcvm)
        {
            if (pcvm != null)
            {

                await _classParentService.AddSchoolClassAdnAssociatedTParent(pcvm);
                return Ok();
            }
            return BadRequest();
        }
        [HttpGet("getAllParentsForClass/{id}")]
        public async Task<List<ParentViewModel>> getNonReadNoticesforClass(int id)
        {

            var parnetList = await _classParentService.GetParentsForClasses(id);
            
            var parentViews = new List<ParentViewModel>();


            foreach (var parent in parnetList)
            {


                var parentView = new ParentViewModel();
                var p = _userManager.FindByIdAsync(parent.applicationUserId).Result;
                parentView.email = p.Email;
                parentView.fullname = p.FirstName + " " + p.LastName;
                parentViews.Add(parentView);

            }                       
            return parentViews;
        }

    }
}
