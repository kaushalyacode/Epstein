﻿using Final.Service.ViewModel;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final.Connector.HubConfig
{
    public class NoticeHub: Hub
    {
        public async Task BroadcastMessegetData(List<MessgInfoViewModel> data) => await Clients.All.SendAsync("brodcastmessegedata", data);
    }
}
