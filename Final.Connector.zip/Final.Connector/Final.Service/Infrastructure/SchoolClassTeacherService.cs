﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class SchoolClassTeacherService : ISchoolClassTeacherService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<SchoolClassTeacher> _schoolClassTeacherRepository { get; set; }

        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }


        public SchoolClassTeacherService(IBaseRepository<SchoolClassTeacher> repo, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            this._schoolClassTeacherRepository = repo;
            this._uow = uow;
            this._mapper = mapper;

        }

        public async Task<bool> AddSchoolClassAdnAssociatedTeacher(SchoolClassTeacherViewModel schoolClassTeacherViewModel)
        {
            try
            {
                SchoolClassTeacher sct = new SchoolClassTeacher();
                sct.classId = schoolClassTeacherViewModel.classId;
                sct.subject = schoolClassTeacherViewModel.subject;
                sct.AddedDateTime = DateTime.Now;
                var user = await _userManager.FindByEmailAsync(schoolClassTeacherViewModel.classTeacherEmail);
                sct.classTeacherId = user.Id;
                await _schoolClassTeacherRepository.CreateAsync(sct).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public async Task<List<SchoolClassTeacher>> GetClassesForTeacher(string email)
        {
            if (email != null)
            {
                var user = await _userManager.FindByEmailAsync(email);
                var schoolClasses = _schoolClassTeacherRepository.GetByCondition(e => (e.classTeacherId == user.Id)).ToList();
                return schoolClasses;
            }
            return new List<SchoolClassTeacher>();
        }

        public async Task<List<SchoolClassTeacher>> GetTeachersForClasses(int classid)
        {
            if (classid != null)
            {
                var schoolClassesTeacher = _schoolClassTeacherRepository.GetByCondition(e => (e.classId == classid)).ToList();
                return schoolClassesTeacher;
            }
            return new List<SchoolClassTeacher>();
        }
    }
}