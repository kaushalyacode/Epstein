﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public interface ISchoolClassTeacherService
    {
        Task<bool> AddSchoolClassAdnAssociatedTeacher(SchoolClassTeacherViewModel schoolClassTeacherViewModel);
        Task<List<SchoolClassTeacher>> GetClassesForTeacher(string email);
        Task<List<SchoolClassTeacher>> GetTeachersForClasses(int classId);
    }
}
