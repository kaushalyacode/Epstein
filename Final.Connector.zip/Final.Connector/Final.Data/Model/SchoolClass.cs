﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Data.Model
{
    //teachers role as home room teacher
    public class SchoolClass :BaseEntity
    {
        public string ClassName { get; set; }
        [System.ComponentModel.DataAnnotations.Schema.ForeignKey("ApplicationUser")]
        public string ApplicationUserID { get; set; }
        [DefaultValue(100)]
        public int numberOfStudents { get; set; }

        public ApplicationUser ApplicationUser { get; set; }
    }
}
