﻿namespace Final.Data.Model
{
    public class ParentNotification :BaseEntity
    {
        public string ApplicationUserId { get; set; }

        public int NoticeId { get; set; }

        public bool isAccepted { get; set; }

    }
}
