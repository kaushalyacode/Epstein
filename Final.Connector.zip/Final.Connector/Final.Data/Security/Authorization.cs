﻿namespace Final.Data.Security
{
    public class Authorization
    {
        public enum Roles
        {
            Administrator,
            Teacher,
            Student,
            Parent
        }
        public const string default_username = "parent";
        public const string default_email = "parent@secureapi.com";
        public const string default_password = " Pa$$w0rd.";
        public const Roles default_role = Roles.Parent;
    }
}
