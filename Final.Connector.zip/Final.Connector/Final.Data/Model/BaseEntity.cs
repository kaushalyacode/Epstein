﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Final.Data.Model
{
    public class BaseEntity : IBaseEntity
    {
        [Key]
        public int Id { get; set; }

        [DefaultValue(false)]
        public bool IsActive { get; set; }

        [DefaultValue(false)]
        public bool IsDeleted { get; set; }

        public DateTime AddedDateTime
        {
            get
            {
                return this.dateCreated.HasValue
                   ? this.dateCreated.Value
                   : DateTime.Now;
            }

            set { this.dateCreated = value; }
        }

        private DateTime? dateCreated = null;
        public DateTime? UpdatedDateTime { get; set; }
        public string UpdatedBy { get; set; }
        public string AddedBy { get; set; }

    }
}
