﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Final.Data.Migrations
{
    public partial class newCommonNotice : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "id",
                table: "Notices",
                newName: "Id");

            migrationBuilder.AddColumn<string>(
                name: "AddedBy",
                table: "Notices",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "AddedDateTime",
                table: "Notices",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "Notices",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "UpdatedBy",
                table: "Notices",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "UpdatedDateTime",
                table: "Notices",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AddedBy",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "AddedDateTime",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "IsActive",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "UpdatedBy",
                table: "Notices");

            migrationBuilder.DropColumn(
                name: "UpdatedDateTime",
                table: "Notices");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Notices",
                newName: "id");
        }
    }
}
