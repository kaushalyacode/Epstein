﻿using Final.Data.Model;
using Final.Service.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Interfaces
{
    public interface IParentTeacherMessegesService
    {
        Task<bool> AddMessge(ParentTeacherMessegesViewModel pm); 

        Task<bool> AddMessgeByTeacher(ParentTeacherMessegesViewModel pm);


        Task<int> getConnectionId(string teacherid, string parentid);
        Task<List<MessgeInfo>> getMessgesForTeacher(int connectionid);
    }
}
