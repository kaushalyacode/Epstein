﻿using AutoMapper;
using Final.Data.Model;
using Final.Data.Repository;
using Final.Data.UnitOfWork;
using Final.Service.Interfaces;
using Final.Service.ViewModel;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final.Service.Infrastructure
{
    public class TeachersNotificationService : ITeachersNotificationService
    {

        private readonly UserManager<ApplicationUser> _userManager;
        private IBaseRepository<TeachersNotification> _teacherNotificationRepository { get; set; }

        private  ISchoolClassTeacherService _schoolClassTeacherService { get; set; }

        private ISchoolClassService _schoolClassService { get; set; }
        

        private readonly ICommonNoticeService _commonNoticeService;
        private IUnitOfWork _uow { get; set; }

        private IMapper _mapper { get; set; }



        public TeachersNotificationService(ISchoolClassService schoolClassService,ISchoolClassTeacherService schoolClassTeacherService,ICommonNoticeService sv,IBaseRepository<TeachersNotification> repo, IUnitOfWork uow, IMapper mapper, UserManager<ApplicationUser> userManager)
        {
            _schoolClassService = schoolClassService;
            _schoolClassTeacherService = schoolClassTeacherService;
            _userManager = userManager;
            this._teacherNotificationRepository = repo;
            this._uow = uow;
            this._mapper = mapper;
            _commonNoticeService=sv;

        }

        public async Task<bool> AddTeacherNotification(ParentNotificationViewModel teachersNotificationViewModel)
        {
            try
            {
                TeachersNotification teachersNotification = _mapper.Map<TeachersNotification>(teachersNotificationViewModel);
                var user = await _userManager.FindByEmailAsync(teachersNotificationViewModel.teacherEmail);
                teachersNotification.ApplicationUserId = user.Id;
                await _teacherNotificationRepository.CreateAsync(teachersNotification).ConfigureAwait(false);
                await _uow.Commit().ConfigureAwait(false);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }

        public async Task<List<TeachersNotification>> GetNotifications(string email)
        {
            if (email != null)
            {
                var user = await _userManager.FindByEmailAsync(email);
                var tn = _teacherNotificationRepository.GetByCondition(e => (e.ApplicationUserId == user.Id)).ToList();
                return tn;
            }
            return new List<TeachersNotification>();
        }

        public async Task<List<CommonNotice>> getNonReadNoticesNotifications(string email)
        {
            try
            {
                if (email != null)
                {
                    var claasIdLit = _schoolClassTeacherService.GetClassesForTeacher(email).Result.Select(e => e.classId).ToList();
                    var allSectionNotice = new List<CommonNotice>();
                    foreach (var cid in claasIdLit)
                    {
                        allSectionNotice.AddRange(await _commonNoticeService.GetNoticeBySection(_schoolClassService.
                            GetClassUsingId(cid).
                            Result.
                            ClassName.
                            FirstOrDefault()));
                    }
                    var noticeIdSet = allSectionNotice.Select(x => x.Id).ToList();
                    foreach (var singleNoticeID in noticeIdSet)
                    {
                        if (_teacherNotificationRepository.GetAllAsync().Result.Where(e => e.NoticeId == singleNoticeID).Any())
                        {
                            allSectionNotice.RemoveAll(x => x.Id == singleNoticeID);
                        }

                    }
                    return allSectionNotice;
                }
            }
            catch (Exception e)
            {
                return new List<CommonNotice>();
            }
            return new List<CommonNotice>();
        }
    }
}
